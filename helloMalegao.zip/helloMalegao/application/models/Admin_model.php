<?php
class Admin_model extends CI_Model
{
    public function validateadmin($username,$password)
    {
        $this->db->select("*");
        $this->db->from('userlogin');
        $this->db->where('username',$username);
        $this->db->where('password',$password);
        $query = $this->db->get();
        if($query->num_rows())
            return $query->result_array();
        else
            return false;     
    }

     public function getallcategories()
    {
        $this->db->select("*");
        $this->db->from('categories');
        $query = $this->db->get();
        if($query->num_rows())
            return $query->result_array();
        else
            return false;     
    }

     public function getservices($cat_id)
    {
        $this->db->select("*");
        $this->db->from('services');
        $this->db->where('cat_id',$cat_id);
        $query = $this->db->get();
        if($query->num_rows())
            return $query->result_array();
        else
            return false;     
    }
    public function addservice($data)
    {
        $res = $this->db->insert('services',$data);
        if ($res) {
            return true;
        }
    }
}