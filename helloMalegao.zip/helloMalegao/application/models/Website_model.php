<?php
class Website_model extends CI_Model
{
	public function getServices($catid)
    {
        
        $this->db->select('*');
        $this->db->from('services');
        $this->db->where('cat_id',$catid);
        $query = $this->db->get();

        if($query->num_rows())
        {
        	$this->db->select('cat_name');
	        $this->db->from('categories');
	        $this->db->where('cat_id',$catid);
	        $q = $this->db->get();
	        $catname=$q->result();
        	$a=array("category_name"=>$catname[0]->cat_name,"services"=>$query->result());
        	return $a;
        }
        else
        {
            return false;
        }

    }
    
}