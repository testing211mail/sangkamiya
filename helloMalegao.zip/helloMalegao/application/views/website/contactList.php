<div class="container">
	<div class="alert alert-primary">
		<div class="media">
			<img class="d-flex align-self-center mr-3" src="https://static.pexels.com/photos/162553/keys-workshop-mechanic-tools-162553.jpeg" alt="Generic placeholder image" style="height: 200px;width:200px;">
			<div class="media-body">
				<h5 class="mt-0">NAME :</h5>
				<p>ADDRESS.</p>
				<p class="mb-0"> CONTACT</p>
			</div>
		</div>
	</div>
</div>

