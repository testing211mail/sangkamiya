<div class="container">

	<div class="alert nb-majha text-center">
		<h1 class="underline"><?php print_r($servList['category_name']);  ?></h1>
	</div><br><br>

	<div class='row text-center'>
		<?php
		$i=0;
		foreach($servList['services'] as $ed) {
			echo '<div class="col-lg-2">';
				echo '<div class="card border-dark hvr-grow ulnone" style="height:150px;width:150px;">';
					echo '<a href="'.base_url().'home/contactList/'.$ed->ser_id.'">';
						echo '<img class="card-img-top" src="'.$ed->iconlink.'" alt="Card image cap" style="height:100px;width:100%;">'; 
						echo '<div class="card-footer">';
							echo '<h5 class="card-title text-purple">'.$ed->service_name.'</h5>';
						echo '</div>';
					echo '</a>';
				echo '</div>';
			echo '</div>';
			$i++;
			if ($i % 6 == 0) {echo '</div><div class="row">';}
		}
		?>
	</div>
</div>