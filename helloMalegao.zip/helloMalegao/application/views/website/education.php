<div class="alert nb-majha">
		<h1 class="underline"><?php print_r($servList['category_name']);  ?></h1>
</div>

	<br><br>
	<div class="container ulnone">

	<div class='row text-center'>
		<?php
		$i=0;
		foreach($servList['services'] as $ed) {
			echo '<div class="col-lg-2 col-md-3 col-xs-6 hvr-grow">';
			  echo '<a href="'.base_url().'home/contactList/'.$ed->ser_id.'" class="d-block mb-4 h-100">';
			    echo '<img class="img-fluid" src="'.$ed->iconlink.'" alt="Image" style="height:150px;width:150px;">';
			    	echo '<h5><div class="rounded nb-majha" style="margin-top:7px;">'.$ed->service_name.'</div></h5>';
			  echo '</a>';
			echo '</div>';			
			$i++;
			if ($i % 6 == 0) {echo '</div><div class="row text-center">';}
		}
		?>
	</div>
</div>

