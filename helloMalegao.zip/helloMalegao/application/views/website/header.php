
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php if (isset($title)) { echo $title; } else { echo "Success Business"; } ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url();?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url();?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/carousel.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/animate.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/myStyles.css" rel="stylesheet" type="text/css">
  <link href="<?php echo base_url();?>assets/css/hover-min.css" rel="stylesheet" type="text/css">
</head>
<body>

  <header>
      <nav class="navbar navbar-expand-md navbar-dark fixed-top nb-majha">
        <a class="navbar-brand hvr-underline-from-center" href="<?php echo base_url().'home';?>">Success Business</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
        
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link hvr-underline-from-center" href="#">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link hvr-underline-from-center" href="#">Abous Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link hvr-underline-from-center" href="#">Feedback</a>
            </li>
          </ul>
            <form class="form-inline mt-2 mt-md-0 my-2 my-lg-0">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Search" aria-label="Recipient's username" aria-describedby="basic-addon2">
            <div class="input-group-append">
              <button class="btn btn-outline-secondary" type="button"><i class="fa fa-search" aria-hidden="true"></i></button>
            </div>
          </div>
        </form>
        </div>
      </nav>
    </header>

    <main role="main">

      <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="3000">
        <ol class="carousel-indicators">
          <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
          <li data-target="#myCarousel" data-slide-to="1"></li>
          <li data-target="#myCarousel" data-slide-to="2"></li>
          <li data-target="#myCarousel" data-slide-to="3"></li>
          <li data-target="#myCarousel" data-slide-to="4"></li>
        </ol>
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img class="first-slide animated zoomInDown w-100 h-100" src="<?php echo $imgLinks[0]; ?>" alt="First slide">
          </div>
          <div class="carousel-item">
            <img class="second-slide animated zoomInDown w-100 h-100" src="<?php echo $imgLinks[1]; ?>" alt="Second slide">
          </div>
          <div class="carousel-item">
            <img class="third-slide animated zoomInDown w-100 h-100" src="<?php echo $imgLinks[2]; ?>" alt="Third slide">
          </div>
          <div class="carousel-item">
            <img class="fourth-slide animated zoomInDown w-100 h-100" src="<?php echo $imgLinks[3]; ?>" alt="Fourth slide">
          </div>
          <div class="carousel-item">
            <img class="fifth-slide animated zoomInDownw-100 h-100" src="<?php echo $imgLinks[4]; ?>" alt="Fifth slide">
          </div>
        </div>
        <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="sr-only">Next</span>
        </a>
      </div>
