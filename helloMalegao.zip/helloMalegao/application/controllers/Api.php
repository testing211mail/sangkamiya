<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . 'libraries/REST_Controller.php';

/**
 * This is an example of a few basic user interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 */
class Api extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
       /* $this->load->model('apiuser');
        $dbconnect = $this->load->database();     
        $this->methods['users_post']['limit'] = 100; // 100 requests per hour per user/key
        */
    }

   

    public function demo_post()
    {
    	 $this->response(
                  array('success'=>'true'));
       //$data=$this->post();
        //echo "yo";
        
       
    }


   

}
