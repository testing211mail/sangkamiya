<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	var $links;
    public function __construct() 
    {
        parent::__construct();
        $this->getRandomImages();
        $this->load->model('Website_model');      
    }

	public function index()
	{
		$data['imgLinks']=$this->links;
		$data['title']= 'Success Business';
    	$data['main_content'] = 'website/index.php';
    	$this->load->view('website/template', $data);
	}
	public function education()
	{
		$catId=2;
		$data['imgLinks']=$this->links;
		$data['title']= 'education';
		$data['servList'] = $this->Website_model->getServices($catId);
    	$data['main_content'] = 'website/education.php';
    	$this->load->view('website/template', $data);
	}
	public function health()
	{
		$catId=4;
		$data['imgLinks']=$this->links;
		$data['title']= 'health';
		$data['servList'] = $this->Website_model->getServices($catId);
    	$data['main_content'] = 'website/health.php';
    	$this->load->view('website/template', $data);
	}
	public function government()
	{
		$catId=3;
		$data['imgLinks']=$this->links;
		$data['title']= 'government';
		$data['servList'] = $this->Website_model->getServices($catId);
    	$data['main_content'] = 'website/govt.php';
    	$this->load->view('website/template', $data);
	}
	public function lifestyle()
	{
		$catId=5;
		$data['imgLinks']=$this->links;
		$data['title']= 'lifestyle';
		$data['servList'] = $this->Website_model->getServices($catId);
    	$data['main_content'] = 'website/lifestyle.php';
    	$this->load->view('website/template', $data);
	}
	public function services()
	{
		$catId=6;
		$data['imgLinks']=$this->links;
		$data['title']= 'services';
		$data['servList'] = $this->Website_model->getServices($catId);
    	$data['main_content'] = 'website/services.php';
    	$this->load->view('website/template', $data);
	}
	public function food()
	{
		$catId=2;
		$data['imgLinks']=$this->links;
		$data['title']= 'food';
		$data['servList'] = $this->Website_model->getServices($catId);
    	$data['main_content'] = 'website/food.php';
    	$this->load->view('website/template', $data);
	}

	public function shops()
	{
		$catId=7;
		$data['imgLinks']=$this->links;
		$data['title']= 'shops';
		$data['servList'] = $this->Website_model->getServices($catId);
    	$data['main_content'] = 'website/shops.php';
    	$this->load->view('website/template', $data);
	}

	public function offers()
	{
		$catId=8;
		$data['imgLinks']=$this->links;
		$data['title']= 'offers';
    	$data['main_content'] = 'website/offers.php';
    	$this->load->view('website/template', $data);
	}

	public function getRandomImages()
	{
		$loc = base_url()."uploads/jon/";
  		$this->links = array($loc."adv1.jpg", $loc."adv2.jpg", $loc."adv3.jpg",$loc."adv4.jpg",$loc."adv5.jpg");
	}

	public function contactList($serId)
	{
		$data['imgLinks']=$this->links;
		$data['title']= 'Contacts';
    	$data['main_content'] = 'website/contactList.php';
    	$this->load->view('website/template', $data);
	}
}
