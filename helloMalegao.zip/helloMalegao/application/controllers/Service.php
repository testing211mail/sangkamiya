<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Service extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('admin_model');
        if (!$this->session->userdata('adminlogged_in')) {
              $this->load->view('adminLogin');
          }  
    }

    public function index()
    {
        $data['title']= 'List Services';
        $data['main_content'] = 'listServices';
        $data['result'] = $this->admin_model->getallcategories();
        //print_r($data);exit();
        $this->load->view('template', $data);
    }

    public function getServices()
    {
        $formdata = $this->input->post();
        //$formdata['category'] = "2";
        if (isset($formdata['category'])) {
        $resultArr = $this->admin_model->getServices($formdata['category']);
        //print_r($resultArr);exit();
            if ($resultArr)
            {
                echo json_encode($resultArr);
            }
            die();
      }
    }

    public function addservice()
    {
        $formdata = $this->input->post();
        $catid = $formdata['category'];
        $servicename = $formdata['serviceName'];
        $data1 = [];
        $config['upload_path']=base_url()."upload/cat";
        $config['allowed_types']='gif|jpg|png';
        $this->load->library('upload',$config);
        if($this->upload->do_upload($formdata['file'])){
        $data = array('upload_data' => $this->upload->data());
        $data1['cat_id'] = $catid;
        $data1['service_name'] = $servicename;
        $data1['iconlink'] = $data['upload_data']['file_name'];
        $result = $this->admin_model->addservice($data1);
        if ($result == TRUE) {
            return "ok";
        }
        }
    }
}