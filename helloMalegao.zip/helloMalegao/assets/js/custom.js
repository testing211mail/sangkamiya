
/* HTML document is loaded. DOM is ready. 
-------------------------------------------*/
$(document).ready(function() {
  /* wow
  -------------------------------*/
  new WOW({ mobile: false }).init();
  });

